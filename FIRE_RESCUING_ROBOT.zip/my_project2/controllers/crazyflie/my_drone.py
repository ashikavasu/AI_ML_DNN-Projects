"""gps_controller controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot
from pid import *
import math 
from controller import Keyboard,CameraRecognitionObject

def run_robot(robot):
    
    # get the time step of the current world.
    timestep = int(robot.getBasicTimeStep())
    clr_reg = CameraRecognitionObject()
    
    #Radio Emitter
    emmitter = robot.getDevice('emitter')
    
    #motors
    m1_motor = robot.getDevice('m1_motor')
    m1_motor.setPosition(float('inf'))
    m1_motor.setVelocity(float(-1.0))
    
    m2_motor = robot.getDevice('m2_motor')
    m2_motor.setPosition(float('inf'))
    m2_motor.setVelocity(float(1.0))
    
    m3_motor = robot.getDevice('m3_motor')
    m3_motor.setPosition(float('inf'))
    m3_motor.setVelocity(float(-1.0))
    
    m4_motor = robot.getDevice('m4_motor')
    m4_motor.setPosition(float('inf'))
    m4_motor.setVelocity(float(1.0))
    
    #Inertial Unit
    imu = robot.getDevice('inertial unit')
    imu.enable(timestep)

    #GPS
    gps = robot.getDevice('gps')
    gps.enable(timestep)

    #Keyboard
    kb = Keyboard()
    kb.enable(timestep)
    
    #Gyro
    gyro = robot.getDevice('gyro')
    gyro.enable(timestep)
    
    #camera
    camera = robot.getDevice('camera')
    camera.enable(timestep)
    
    camera.recognitionEnable(timestep)
    
    # image = camera.getImage()
    # print("***********")
    
    # image = camera.getImageArray()
    # print(image)
    # if image:
      # ##display the components of each pixel
       # for x in range(0,camera.getWidth()):
          # for y in range(0,camera.getHeight()):
              # print("hello")
             # red   = image[x][y][0]
             # green = image[x][y][1]
             # blue   = image[x][y][2]
             # gray  = (red + green + blue) / 3
             # print('r='+str(red)+' g='+str(green)+' b='+str(blue))
    

    
    #range
    range_front = robot.getDevice('range_front')
    range_front.enable(timestep)
    range_back = robot.getDevice('range_back')
    range_back.enable(timestep)
    range_right = robot.getDevice('range_right')
    range_right.enable(timestep)
    range_left = robot.getDevice('range_left')
    range_left.enable(timestep)


    while robot.step(timestep) != -1:
        if robot.getTime() > 2.0:
            break

    #state
    actual_state = actual_state_t(0,0,0,0,0,0)
    desired_state = desired_state_t(0,0,0,0,0,0)

    desired_state.roll = 0
    desired_state.pitch = 0
    desired_state.vx = 0
    desired_state.vy = 0
    desired_state.yaw_rate = 0
    desired_state.altitude = 1.0

    past_x_global = 0
    past_y_global = 0
    
    past_time = robot.getTime()
    
    gains_pid = gains_pid_t(10,5,50,0.5,0.1,1,0.5,2,0.5)
    init_pid_attitude_fixed_height_controller()
    
    motor_power = motor_power_t(10,10,10,10)
    
    # Main loop:
    # - perform simulation steps until Webots is stopping the controller
    while robot.step(timestep) != -1:
    
        # reg = camera.getRecognitionNumberOfObjects()
        # print(reg)
        
        clr = clr_reg.getColors()
        print(clr)
        
        # firstObject = Camera.getRecognitionObjects()[0]
        # id = firstObject.get_id()
        # position = firstObject.get_position()
    
        # reg_obj = clr_reg.getColors()
        # print(reg_obj.colors)
        # image = camera.getImageArray()
        # print(image)
        # if image:
            # ##display the components of each pixel
           # for x in range(0,camera.getWidth()):
              # for y in range(0,camera.getHeight()):
                     # print("hello")
                     
        print(range_front.getValue())
        dt = robot.getTime() - past_time
        
        actual_state.roll = imu.getRollPitchYaw()[0]
        actual_state.pitch = imu.getRollPitchYaw()[1]
        actual_state.yaw_rate = gyro.getValues()[2]
        actual_state.altitude = gps.getValues()[2]

        x_global = gps.getValues()[0]
        vx_global = (x_global - past_x_global) / dt
        y_global = gps.getValues()[1]
        vy_global = (y_global - past_y_global) / dt

        actualYaw = imu.getRollPitchYaw()[2]
        cosyaw = math.cos(actualYaw)
        sinyaw = math.sin(actualYaw)
        actual_state.vx = vx_global * cosyaw + vy_global * sinyaw
        actual_state.vy = -vx_global * sinyaw + vy_global * cosyaw
        
        forward_desired = 0
        sideways_desired = 0
        yaw_desired = 0

        key = kb.getKey()
        
        while (key>0):
            #print(key)
            if key == Keyboard.UP:
                forward_desired = +0.2
                break
            elif key == Keyboard.DOWN:
                forward_desired = -0.2
                break
            elif key == Keyboard.RIGHT:
                sideways_desired = -0.2
                break
            elif key == Keyboard.LEFT:
                sideways_desired = +0.2 
                break
            elif key == 81:
                yaw_desired = 0.5 
                
                break
            elif key == 69:
                yaw_desired = -0.5
                break
            else:
                break
                          
        key = kb.getKey()
       
        
        desired_state.yaw_rate = yaw_desired
        
        desired_state.vy = sideways_desired
        desired_state.vx = forward_desired
        
        pid_velocity_fixed_height_controller(actual_state, desired_state, gains_pid, dt, motor_power)
        
        m1_motor.setVelocity(-motor_power.m1)
        m2_motor.setVelocity(motor_power.m2)
        m3_motor.setVelocity(-motor_power.m3)
        m4_motor.setVelocity(motor_power.m4)

        past_time = robot.getTime()
        past_x_global = x_global
        past_y_global = y_global

       

if __name__ == "__main__":
    # create the Robot instance.
    my_robot = Robot()
    run_robot(my_robot)
    



# Enter here exit cleanup code.
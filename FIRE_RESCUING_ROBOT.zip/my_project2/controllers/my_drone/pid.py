import math

class actual_state_t:
    def __init__(self, altitude, pitch, roll, yaw_rate, vx, vy):
        self.altitude = altitude
        self.pitch = pitch
        self.roll = roll
        self.yaw_rate = yaw_rate
        self.vx = vx
        self.vy = vy

class desired_state_t:
    def __init__(self, altitude, pitch, roll, yaw_rate, vx, vy):
        self.altitude = altitude
        self.pitch = pitch
        self.roll = roll
        self.yaw_rate = yaw_rate
        self.vx = vx
        self.vy = vy

class gains_pid_t:
    def __init__(self, kp_z, kd_z, ki_z, kp_att_rp, kd_att_rp, kp_att_y,kd_att_y, kp_vel_xy, kd_vel_xy):
        self.kp_z = kp_z
        self.kd_z = kd_z
        self.ki_z = ki_z
        self.kp_att_rp = kp_att_rp
        self.kd_att_rp = kd_att_rp
        self.kp_att_y = kp_att_y
        self.kd_att_y = kd_att_y
        self.kp_vel_xy = kp_vel_xy
        self.kd_vel_xy = kd_vel_xy

class motor_power_t:
    def __init__(self, m1, m2, m3, m4):
        self.m1 = m1
        self.m2 = m2
        self.m3 = m3
        self.m4 = m4

class control_commands_t:
    def __init__(self, altitude=0, roll=0, pitch=0, yaw=0):
        self.altitude = altitude
        self.roll = roll
        self.pitch = pitch
        self.yaw = yaw

def constrain(value, min_val, max_val):
    return min(max_val, max(min_val, value))

pastAltitudeError = 0
pastYawRateError = 0
pastPitchError = 0
pastRollError = 0
pastVxError = 0
pastVyError = 0

def init_pid_attitude_fixed_height_controller():
    global pastAltitudeError, pastYawRateError, pastPitchError, pastRollError, pastVxError, pastVyError
    pastAltitudeError = 0
    pastYawRateError = 0
    pastPitchError = 0
    pastRollError = 0
    pastVxError = 0
    pastVyError = 0

def pid_attitude_fixed_height_controller(actual_state, desired_state, gains_pid, dt, motor_power_t):
    control_commands = control_commands_t()
    pid_fixed_height_controller(actual_state, desired_state, gains_pid, dt, control_commands)
    pid_attitude_controller(actual_state, desired_state, gains_pid, dt, control_commands)
    motor_mixing(control_commands, motor_power_t)

def pid_velocity_fixed_height_controller(actual_state, desired_state, gains_pid, dt, motor_power_t):
    control_commands = control_commands_t()
    pid_horizontal_velocity_controller(actual_state, desired_state, gains_pid, dt)
    pid_fixed_height_controller(actual_state, desired_state, gains_pid, dt, control_commands)
    pid_attitude_controller(actual_state, desired_state, gains_pid, dt, control_commands)
    motor_mixing(control_commands, motor_power_t)

def pid_fixed_height_controller(actual_state, desired_state, gains_pid, dt, control_commands):
    global pastAltitudeError
    altitudeError = desired_state.altitude - actual_state.altitude
    altitudeDerivativeError = (altitudeError - pastAltitudeError) / dt
    control_commands.altitude = gains_pid.kp_z * constrain(altitudeError, -1, 1) + gains_pid.kd_z * altitudeDerivativeError + gains_pid.ki_z
    pastAltitudeError = altitudeError


def motor_mixing(control_commands, motor_power_t):
    # Motor mixing
    motor_power_t.m1 = control_commands.altitude - control_commands.roll + control_commands.pitch + control_commands.yaw
    motor_power_t.m2 = control_commands.altitude - control_commands.roll - control_commands.pitch - control_commands.yaw
    motor_power_t.m3 = control_commands.altitude + control_commands.roll - control_commands.pitch + control_commands.yaw
    motor_power_t.m4 = control_commands.altitude + control_commands.roll + control_commands.pitch - control_commands.yaw

def pid_attitude_controller(actual_state, desired_state, gains_pid, dt, control_commands):
    global pastPitchError, pastRollError, pastYawRateError
    # Calculate errors
    pitchError = desired_state.pitch - actual_state.pitch
    pitchDerivativeError = (pitchError - pastPitchError) / dt
    rollError = desired_state.roll - actual_state.roll
    rollDerivativeError = (rollError - pastRollError) / dt
    yawRateError = desired_state.yaw_rate - actual_state.yaw_rate

    # PID control
    control_commands.roll = gains_pid.kp_att_rp * constrain(rollError, -1, 1) + gains_pid.kd_att_rp * rollDerivativeError
    control_commands.pitch = -gains_pid.kp_att_rp * constrain(pitchError, -1, 1) - gains_pid.kd_att_rp * pitchDerivativeError
    control_commands.yaw = gains_pid.kp_att_y * constrain(yawRateError, -1, 1)

    # Save error for the next round
    pastPitchError = pitchError
    pastRollError = rollError
    pastYawRateError = yawRateError


def pid_horizontal_velocity_controller(actual_state, desired_state, gains_pid, dt):
    global pastVxError, pastVyError
    vxError = desired_state.vx - actual_state.vx
    vxDerivative = (vxError - pastVxError) / dt
    vyError = desired_state.vy - actual_state.vy
    vyDerivative = (vyError - pastVyError) / dt

    # PID control
    pitchCommand = gains_pid.kp_vel_xy * constrain(vxError, -1, 1) + gains_pid.kd_vel_xy * vxDerivative
    rollCommand = -gains_pid.kp_vel_xy * constrain(vyError, -1, 1) - gains_pid.kd_vel_xy * vyDerivative

    desired_state.pitch = pitchCommand
    desired_state.roll = rollCommand

    # Save error for the next round
    pastVxError = vxError
    pastVyError = vyError
    


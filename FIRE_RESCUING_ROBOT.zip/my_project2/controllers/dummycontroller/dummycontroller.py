"""gps_controller controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot
from pid import *
import math,struct
import numpy as np
from controller import Keyboard,CameraRecognitionObject,DistanceSensor,Emitter,Receiver

def run_robot(robot):
    
    # get the time step of the current world.
    timestep = int(robot.getBasicTimeStep())
    clr_reg = CameraRecognitionObject()
 
    
    
    #Radio Emitter
    emitter_dev = robot.getDevice('emitter')
    
    
    #receiver
    receiver_dev = robot.getDevice('receiver')
    
    
    #motors
    m1_motor_val = robot.getDevice('m1_motor')
    m1_motor_val.setPosition(float('inf'))
    m1_motor_val.setVelocity(float(-1.0))
    
    m2_motor_val = robot.getDevice('m2_motor')
    m2_motor_val.setPosition(float('inf'))
    m2_motor_val.setVelocity(float(1.0))
    
    m3_motor_val = robot.getDevice('m3_motor')
    m3_motor_val.setPosition(float('inf'))
    m3_motor_val.setVelocity(float(-1.0))
    
    m4_motor_val = robot.getDevice('m4_motor')
    m4_motor_val.setPosition(float('inf'))
    m4_motor_val.setVelocity(float(1.0))
    
    
    #Inertial Unit
    iner_uni = robot.getDevice('inertial unit')
    iner_uni.enable(timestep)

    #GPS
    gps = robot.getDevice('gps')
    gps.enable(timestep)

    #Keyboard
    kb = Keyboard()
    kb.enable(timestep)
    
    #Gyro
    gyro = robot.getDevice('gyro')
    gyro.enable(timestep)
    
    #camera
    camera = robot.getDevice('camera')
    camera.enable(timestep)
    
    
    
    camera.recognitionEnable(timestep)
    
    #distance sensor
    dis0 = robot.getDevice('ds_F')
    dis0.enable(timestep)
    
    dis1= robot.getDevice('ds_L')
    dis1.enable(timestep)
    
    dis2 = robot.getDevice('ds_R')
    dis2.enable(timestep)
    
    dis3 = robot.getDevice('ds_new1')
    dis3.enable(timestep)
    
    dis4 = robot.getDevice('ds_new2')
    dis4.enable(timestep)
    
    dis5 = robot.getDevice('ds_new3')
    dis5.enable(timestep)
    
    dis6 = robot.getDevice('ds_new4')
    dis6.enable(timestep)
    
    dis7 = robot.getDevice('ds_new5')
    dis7.enable(timestep)
    
    dis8 = robot.getDevice('ds_new6')
    dis8.enable(timestep)
    
   
    
    
  
    
    # image = camera.getImageArray()
    # print(image)
    # if image == None:
    #   ##display the components of each pixel
    #    for x in range(0,camera.getWidth()):
    #       for y in range(0,camera.getHeight()):
    #           print(x)
    #           print(y)
              # red   = image
              # green = image[x][y][1]
              # blue   = image[x][y][2]
              # gray  = (red + green + blue) / 3
              # print('r='+str(red)+' g='+str(green)+' b='+str(blue))
    

    
    #range
    range_front = robot.getDevice('range_front')
    range_front.enable(timestep)
    range_back = robot.getDevice('range_back')
    range_back.enable(timestep)
    range_right = robot.getDevice('range_right')
    range_right.enable(timestep)
    range_left = robot.getDevice('range_left')
    range_left.enable(timestep)


    while robot.step(timestep) != -1:
        if robot.getTime() > 2.0:
            break

    #state
    real_state = actual_state_t(0,0,0,0,0,0)
    desire_state = desired_state_t(0,0,0,0,0,0)

    desire_state.roll = 0
    desire_state.pitch = 0
    desire_state.vx = 0
    desire_state.vy = 0
    desire_state.yaw_rate = 0
    desire_state.altitude = 1.0

    past_x_global_value = 0
    past_y_global_value = 0
    
    past_time = robot.getTime()
    
    gains_pid = gains_pid_t(10,5,50,0.5,0.1,1,0.5,2,0.5)
    init_pid_attitude_fixed_height_controller()
    
    motor_power = motor_power_t(10,10,10,10)
    
    # Main loop:
    # - perform simulation steps until Webots is stopping the controller
    while robot.step(timestep) != -1:
        
        reg = camera.getRecognitionNumberOfObjects()
        print("no. of objects",reg)
        # print(len(str(reg)))
        firstclr = camera.getRecognitionObjects()
        clr = firstclr[0].getColors()
        print(clr[0],clr[1],clr[2])
        if clr[0]:
           print("Fire alert!!!!!!!")
           emitter_dev.setChannel(0) 
           emitter_dev.send(gps.getValues())
       
        
        #optional
        #receiver_dev.enable(timestep)
        # print("queuelen",receiver_dev.getQueueLength())

        
        # print(receiver_dev.getQueueLength())
        # while receiver_dev.getQueueLength() > 0:
             # message = receiver_dev.getFloats()
             # receiver_dev.nextPacket()
             # print("msg",message)
         
        
        
        # firstObject = Camera.getRecognitionObjects()
        # id = firstObject.get_id()
        # position = firstObject.get_position()
    
        # reg_obj = clr_reg.getColors()
        # print(reg_obj.colors)
        # image = camera.getImageArray()
        # print(image)
        # if image:
            # ##display the components of each pixel
           # for x in range(0,camera.getWidth()):
              # for y in range(0,camera.getHeight()):
                     # print("hello")
                     
        print(range_front.getValue())
        dt = robot.getTime() - past_time
        
        real_state.roll = iner_uni.getRollPitchYaw()[0]
        real_state.pitch = iner_uni.getRollPitchYaw()[1]
        real_state.yaw_rate = gyro.getValues()[2]
        real_state.altitude = gps.getValues()[2]

        x_global = gps.getValues()[0]
        vx_global = (x_global - past_x_global_value) / dt
        y_global = gps.getValues()[1]
        vy_global = (y_global - past_y_global_value) / dt

        actualYaw = iner_uni.getRollPitchYaw()[2]
        cosyaw = math.cos(actualYaw)
        sinyaw = math.sin(actualYaw)
        real_state.vx = vx_global * cosyaw + vy_global * sinyaw
        real_state.vy = -vx_global * sinyaw + vy_global * cosyaw
        
        forward_desired = 0
        sideways_desired = 0
        yaw_desired = 0

        # key = kb.getKey()
        ds_F = dis0.getValue()
        ds_L = dis1.getValue()
        ds_R = dis2.getValue()
        ds_new1 = dis3.getValue()
        ds_new2 = dis4.getValue()
        ds_new3 = dis5.getValue()
        ds_new4 = dis6.getValue()
        ds_new5 = dis7.getValue()
        ds_new6 = dis8.getValue()
        
        print(f"{ds_F},,,,{ds_L},,,{ds_R},,,,{ds_new1},,,,{ds_new2},,,,{ds_new3},,,,{ds_new4},,,{ds_new5},,{ds_new6}")
        # if ds_F >80000:
              # forward_desired = +0.2
              # print("#####")
        if ds_F <=90000 and ds_new3 <= 90000 and range_front.getValue() > 500: 
           print("FFF")
           forward_desired = +0.2 #left
           sideways_desired = +0.2
           
        if range_front.getValue() < 500:
              yaw_desired = -0.4
              sideways_desired = -0.4
        if ds_L < 70000 and range_front.getValue() < 100 :
              forward_desired = -0.2
              yaw_desired = +0.4
              sideways_desired = +0.4
        # if ds_L < 75000 and ds_new6 <= 70000:
            # print("jjj")
            # yaw_desired = -0.2
            # sideways_desired = -0.2
     
            
        # if ds_new5 > 51000 :
             # yaw_desired = -0.2
             # forward_desired = -0.2
           
          
        # if ds_R <= 90000 and ds_new3 < 90000:
               # #sideways_desired = -0.2
               # yaw_desired = -0.4
               # forward_desired = -0.2
               # sideways_desired = +0.5
               
               # forward_desired = +0.2
               # sideways_desired = +0.2
               # yaw_desired = -0.3
              
            
           
           
        
        # if ds_new1 == 90000 and ds_new5 == 90000 and ds_new6 == 90000 and range_front.getValue() >= 2000 :
            # yaw_desired = 0.4
            # sideways_desired = -0.2
            # forward_desired = +0.02
            # print("www")
           # sideways_desired = +0.2
       # if ds_R < 90000 and ds_F < 80000:
              # forward_desired = 0
              # yaw_desired = -1
              
                  
        
        
        

               
            
               
            # if key == Keyboard.UP:
                # forward_desired = +0.2
                # break
            # elif key == Keyboard.DOWN:
                # forward_desired = -0.2
                # break
            # elif key == Keyboard.RIGHT:
                # sideways_desired = -0.2
                # break
            # elif key == Keyboard.LEFT:
                # sideways_desired = +0.2 
                # break
            # elif key == 81:
                # yaw_desired = 0.5 
                
                # break
            # elif key == 69:
                # yaw_desired = -0.5
                # break
            # else:
                # break
       
        
        desire_state.yaw_rate = yaw_desired
        
        desire_state.vy = sideways_desired
        desire_state.vx = forward_desired
        
        pid_velocity_fixed_height_controller(real_state, desire_state, gains_pid, dt, motor_power)
        
        m1_motor_val.setVelocity(-motor_power.m1)
        m2_motor_val.setVelocity(motor_power.m2)
        m3_motor_val.setVelocity(-motor_power.m3)
        m4_motor_val.setVelocity(motor_power.m4)

        past_time = robot.getTime()
        past_x_global_value = x_global
        past_y_global_value = y_global

       

if __name__ == "__main__":
    # create the Robot instance.
    my_robot = Robot()
    run_robot(my_robot)
    



# Enter here exit cleanup code.